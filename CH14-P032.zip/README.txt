CH14-P032: produce IAKESI-CH14-032-art.png, -lettering.png, -text.txt; 1024x1536; CSP ALL CAPS; no page numbers or English inside artwork.
