CH14-P010: produce IAKESI-CH14-010-art.png, -lettering.png, -text.txt; 1024x1536; CSP ALL CAPS; no page numbers or English inside artwork.
